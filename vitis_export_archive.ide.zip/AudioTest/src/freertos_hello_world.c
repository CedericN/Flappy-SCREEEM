/*
    Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
    Copyright (c) 2012 - 2020 Xilinx, Inc. All Rights Reserved.
	SPDX-License-Identifier: MIT


    http://www.FreeRTOS.org
    http://aws.amazon.com/freertos


    1 tab == 4 spaces!
*/

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
/* Xilinx includes. */
#include "xil_printf.h"
#include "xparameters.h"
#include "xbram.h"
#include "pmod_I2S2.h"
#include<stdlib.h>
#include<stdio.h>

#define TIMER_ID	1
#define DELAY_10_SECONDS	10000UL
#define DELAY_1_SECOND		1000UL
#define DELAY_0_SECOND		9UL
#define TIMER_CHECK_THRESHOLD	9

#define BRAMREAD_BASE XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR
#define BRAMPLAY_BASE XPAR_AXI_BRAM_CTRL_1_S_AXI_BASEADDR

#define PMOD_BASEADR XPAR_PMOD_I2S2_0_S00_AXI_BASEADDR
#define PMOD_Reg0 PMOD_I2S2_S00_AXI_SLV_REG0_OFFSET //address 0 = enable read; address 16 down to 1 read buffer size
#define PMOD_Reg1 PMOD_I2S2_S00_AXI_SLV_REG1_OFFSET //address 0 = enable Play; address 16 down to 1 Play buffer size
#define PMOD_Reg2 PMOD_I2S2_S00_AXI_SLV_REG2_OFFSET //current read address
#define PMOD_Reg3 PMOD_I2S2_S00_AXI_SLV_REG3_OFFSET //current write address
/*-----------------------------------------------------------*/

/* The Tx and Rx tasks as described at the top of this file. */
static void prvTxTask( void *pvParameters );
static void prvRxTask( void *pvParameters );
static void vTimerCallback( TimerHandle_t pxTimer );
/*-----------------------------------------------------------*/

/* The queue used by the Tx and Rx tasks, as described at the top of this
file. */
static TaskHandle_t xTxTask;
static TaskHandle_t xRxTask;
static QueueHandle_t xQueue = NULL;
static TimerHandle_t xTimer = NULL;
char HWstring[15] = "Hello World";
long RxtaskCntr = 0;

int main( void )
{
	const TickType_t x10seconds = pdMS_TO_TICKS( DELAY_10_SECONDS );

	xil_printf( "Hello from Freertos example main\r\n" );
	xil_printf("Printing the audio now\r\n");
	/* Create the two tasks.  The Tx task is given a lower priority than the
	Rx task, so the Rx task will leave the Blocked state and pre-empt the Tx
	task as soon as the Tx task places an item in the queue. */
	xTaskCreate( 	prvTxTask, 					/* The function that implements the task. */
					( const char * ) "Tx", 		/* Text name for the task, provided to assist debugging only. */
					configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task. */
					NULL, 						/* The task parameter is not used, so set to NULL. */
					tskIDLE_PRIORITY,			/* The task runs at the idle priority. */
					&xTxTask );

	xTaskCreate( prvRxTask,
				 ( const char * ) "GB",
				 configMINIMAL_STACK_SIZE,
				 NULL,
				 tskIDLE_PRIORITY + 1,
				 &xRxTask );

	/* Create the queue used by the tasks.  The Rx task has a higher priority
	than the Tx task, so will preempt the Tx task and remove values from the
	queue as soon as the Tx task writes to the queue - therefore the queue can
	never have more than one item in it. */
	xQueue = xQueueCreate( 	1,						/* There is only one space in the queue. */
							sizeof( HWstring ) );	/* Each space in the queue is large enough to hold a uint32_t. */

	/* Check the queue was created. */
	configASSERT( xQueue );

	/* Create a timer with a timer expiry of 10 seconds. The timer would expire
	 after 10 seconds and the timer call back would get called. In the timer call back
	 checks are done to ensure that the tasks have been running properly till then.
	 The tasks are deleted in the timer call back and a message is printed to convey that
	 the example has run successfully.
	 The timer expiry is set to 10 seconds and the timer set to not auto reload. */
	xTimer = xTimerCreate( (const char *) "Timer",
							x10seconds,
							pdFALSE,
							(void *) TIMER_ID,
							vTimerCallback);
	/* Check the timer was created. */
	configASSERT( xTimer );

	/* start the timer with a block time of 0 ticks. This means as soon
	   as the schedule starts the timer will start running and will expire after
	   10 seconds */
	xTimerStart( xTimer, 0 );

	/* Start the tasks and timer running. */
	vTaskStartScheduler();

	/* If all is well, the scheduler will now be running, and the following line
	will never be reached.  If the following line does execute, then there was
	insufficient FreeRTOS heap memory available for the idle and/or timer tasks
	to be created.  See the memory management section on the FreeRTOS web site
	for more details. */
	for( ;; );
}


/*-----------------------------------------------------------*/
static void prvTxTask( void *pvParameters )
{
	const TickType_t x1second = pdMS_TO_TICKS( DELAY_1_SECOND );
	const TickType_t x0second = pdMS_TO_TICKS( DELAY_0_SECOND );

	PMOD_I2S2_mWriteReg(PMOD_BASEADR, PMOD_Reg0, 0x01);
	PMOD_I2S2_mWriteReg(PMOD_BASEADR, PMOD_Reg1, 0x01);
	vTaskDelay(x1second);
	//xil_printf("Printing the audio now");
	int size = 65536 *0.75;
	unsigned long *ptra;
	unsigned long *ptrb;
	unsigned long *ptrc;
	ptra = malloc(size*sizeof(*ptra));
	ptrb = malloc(size*sizeof(*ptrb));
	ptrc = malloc(size*sizeof(*ptrc));
		for( ;; )
		{
			XBram_WriteReg(BRAMPLAY_BASE, 0x00, XBram_ReadReg(BRAMREAD_BASE, 0x00));
			vTaskDelay(x0second);
			xil_printf("Gathering data");
		    for(long i = 0; i < size-1; i++)
		    {
		    	vTaskDelay(x0second);
		    	*(ptra + i) = XBram_ReadReg(BRAMREAD_BASE, 0x00);
		    	XBram_WriteReg(BRAMPLAY_BASE, 0x00, *(ptra + i));
		    }
		    for(long i = 0; i < size-1; i++)
		   		    {
		   		    	vTaskDelay(x0second);
		   		    	*(ptrb + i) = XBram_ReadReg(BRAMREAD_BASE, 0x00);
		   		    	XBram_WriteReg(BRAMPLAY_BASE, 0x00, *(ptrb + i));
		   		    }
		    for(long i = 0; i < size-1; i++)
		   		    {
		   		    	vTaskDelay(x0second);
		   		    	*(ptrc + i) = XBram_ReadReg(BRAMREAD_BASE, 0x00);
		   		    	XBram_WriteReg(BRAMPLAY_BASE, 0x00, *(ptrc + i));
		   		    }
		    xil_printf("Printing the audio now");
		    for(int i = 0; i < size-1; i++)
		    {
		    	char str[12];
		    	vTaskDelay(x0second);
		    	//sprintf(str, "%#lx,", *(ptr + i));
		    	//xil_printf(str);
		    }
		    xil_printf("Continue the song");
		    for(;;) {
		    	for(long i = 0; i < size-1; i++){ XBram_WriteReg(BRAMPLAY_BASE, 0x00, *(ptra + i)); }
		    	for(long i = 0; i < size-1; i++){ XBram_WriteReg(BRAMPLAY_BASE, 0x00, *(ptrb + i)); }
		    	for(long i = 0; i < size-1; i++){ XBram_WriteReg(BRAMPLAY_BASE, 0x00, *(ptrc + i)); }
		    }
		    vTaskDelete( xRxTask );
		    vTaskDelete( xTxTask );
		}
}

/*-----------------------------------------------------------*/
static void prvRxTask( void *pvParameters )
{
char Recdstring[15] = "";

//	for( ;; )
//	{
//		/* Block to wait for data arriving on the queue. */
//		xQueueReceive( 	xQueue,				/* The queue being read. */
//						Recdstring,	/* Data is read into this address. */
//						portMAX_DELAY );	/* Wait without a timeout for data. */
//
//		/* Print the received data. */
//		xil_printf( "Rx task received string from Tx task: %s\r\n", Recdstring );
//		RxtaskCntr++;
//	}
}

/*-----------------------------------------------------------*/
static void vTimerCallback( TimerHandle_t pxTimer )
{
	long lTimerId;
	configASSERT( pxTimer );

	lTimerId = ( long ) pvTimerGetTimerID( pxTimer );

	if (lTimerId != TIMER_ID) {
		xil_printf("FreeRTOS Hello World Example FAILED");
	}

	/* If the RxtaskCntr is updated every time the Rx task is called. The
	 Rx task is called every time the Tx task sends a message. The Tx task
	 sends a message every 1 second.
	 The timer expires after 10 seconds. We expect the RxtaskCntr to at least
	 have a value of 9 (TIMER_CHECK_THRESHOLD) when the timer expires. */
	if (RxtaskCntr >= TIMER_CHECK_THRESHOLD) {
		xil_printf("Successfully ran FreeRTOS Hello World Example");
	} else {
		xil_printf("FreeRTOS Hello World Example FAILED");
	}

//	vTaskDelete( xRxTask );
//	vTaskDelete( xTxTask );
}

