/*
    Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
    Copyright (c) 2012 - 2020 Xilinx, Inc. All Rights Reserved.
	SPDX-License-Identifier: MIT


    http://www.FreeRTOS.org
    http://aws.amazon.com/freertos


    1 tab == 4 spaces!
*/

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
/* Xilinx includes. */
#include "xil_printf.h"

/* Own Includes */
#include <vector>
#include "matrix.h"
#include "sleep.h"

#define TIMER_ID	1
#define DELAY_10_SECONDS	10000UL
#define DELAY_1_SECOND		1000UL
#define DELAY_0_5_SECOND	500UL
#define TIMER_CHECK_THRESHOLD	9
/*-----------------------------------------------------------*/

/* The Tx and Rx tasks as described at the top of this file. */
static void prvLedMatrixTask( void *pvParameters );
//static void prvRxTask( void *pvParameters );
static void vTimerCallback( TimerHandle_t pxTimer );
/*-----------------------------------------------------------*/

/* The queue used by the Tx and Rx tasks, as described at the top of this
file. */
static TaskHandle_t xLedMatrixTask;
//static TaskHandle_t xRxTask;
static QueueHandle_t xQueue = NULL;
static TimerHandle_t xTimer = NULL;

int main( void )
{
	const TickType_t x10seconds = pdMS_TO_TICKS( DELAY_10_SECONDS );

	xil_printf( "Hello from Freertos example main\r\n" );

	/* Create the two tasks.  The Tx task is given a lower priority than the
	Rx task, so the Rx task will leave the Blocked state and pre-empt the Tx
	task as soon as the Tx task places an item in the queue. */
	xTaskCreate( 	prvLedMatrixTask, 					/* The function that implements the task. */
					( const char * ) "Tx", 		/* Text name for the task, provided to assist debugging only. */
					800, 	/* The stack allocated to the task. */
					NULL, 						/* The task parameter is not used, so set to NULL. */
					tskIDLE_PRIORITY,			/* The task runs at the idle priority. */
					&xLedMatrixTask );

//	xTaskCreate( prvRxTask,
//				 ( const char * ) "GB",
//				 configMINIMAL_STACK_SIZE,
//				 NULL,
//				 tskIDLE_PRIORITY + 1,
//				 &xRxTask );

	/* Create the queue used by the tasks.  The Rx task has a higher priority
	than the Tx task, so will preempt the Tx task and remove values from the
	queue as soon as the Tx task writes to the queue - therefore the queue can
	never have more than one item in it. */
	xQueue = xQueueCreate( 	1,						/* There is only one space in the queue. */
							sizeof( uint8_t* ) );	/* Each space in the queue is large enough to hold a uint32_t. */

	/* Check the queue was created. */
	configASSERT( xQueue );

	/* Create a timer with a timer expiry of 10 seconds. The timer would expire
	 after 10 seconds and the timer call back would get called. In the timer call back
	 checks are done to ensure that the tasks have been running properly till then.
	 The tasks are deleted in the timer call back and a message is printed to convey that
	 the example has run successfully.
	 The timer expiry is set to 10 seconds and the timer set to not auto reload. */
	xTimer = xTimerCreate( (const char *) "Timer",
							x10seconds,
							pdFALSE,
							(void *) TIMER_ID,
							vTimerCallback);
	/* Check the timer was created. */
	configASSERT( xTimer );

	/* start the timer with a block time of 0 ticks. This means as soon
	   as the schedule starts the timer will start running and will expire after
	   10 seconds */
	xTimerStart( xTimer, 0 );

	/* Start the tasks and timer running. */
	vTaskStartScheduler();

	/* If all is well, the scheduler will now be running, and the following line
	will never be reached.  If the following line does execute, then there was
	insufficient FreeRTOS heap memory available for the idle and/or timer tasks
	to be created.  See the memory management section on the FreeRTOS web site
	for more details. */
	for( ;; );
}


/*-----------------------------------------------------------*/
static void prvLedMatrixTask( void *pvParameters )
{
	const TickType_t x0_5second = pdMS_TO_TICKS( DELAY_0_5_SECOND );
	char bird = 7;
	pair<char, char> pipexy = { 0, 0 };

	//if btn press
	bird = bird + 1;
	vector<vector<unsigned int>> gameFrame {
   		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
   		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
   		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
   		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
   		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
   		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
   		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000}
   };

	vector<vector<unsigned int>> baseFrame {
		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
		 {0x000030, 0x000030, 0x000030, 0x000030, 0x000030, 0x000030, 0x000030, 0x000030}
	};


	vector<vector<unsigned int>> gameOver {
		 {0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000},
		 {0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000},
		 {0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000},
		 {0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000},
		 {0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000},
		 {0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000},
		 {0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000},
		 {0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000, 0x100000}
	};

	vector<vector<unsigned int>> startScreen {
   		 {0x000000, 0x303030, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
   		 {0x303030, 0x000000, 0x303030, 0x303030, 0x000000, 0x000000, 0x000000, 0x303030},
   		 {0x303030, 0x000000, 0x000000, 0x000000, 0x303030, 0x000000, 0x303030, 0x000000},
   		 {0x303030, 0x000000, 0x000000, 0x000000, 0x000000, 0x303030, 0x000000, 0x000000},
   		 {0x303030, 0x000000, 0x000000, 0x000000, 0x303030, 0x000000, 0x303030, 0x000000},
   		 {0x303030, 0x000000, 0x303030, 0x303030, 0x000000, 0x000000, 0x000000, 0x303030},
   		 {0x000000, 0x303030, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000},
		 {0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000}
   };

	//separate me from these variables above me
	gameFrame = baseFrame;
	if (pipexy.first <= -1) { pipexy.second = (rand()%5) + 1; pipexy.first = 8; }
	if(pipexy.first >= 7) { for(int i = 0; i < pipexy.second; i++) { gameFrame[pipexy.first][i] = 0x300000; } }
	gameFrame[1][bird] = 0x303000;
	pipexy.first = pipexy.first-1;
	bird = bird - 1;

	matrix Neopixel(4); //FPS
	uint8_t RecInt = 0;

	for( ;; )
	{
    	Neopixel.setFrame(frame1);

//    	usleep_A9(500000);
    	vTaskDelay( x0_5second );

    	Neopixel.setFrame(frame2);

//    	usleep_A9(500000);
    	vTaskDelay( x0_5second );

    	Neopixel.setFrame(frame3);

//    	usleep_A9(500000);
    	vTaskDelay( x0_5second );

    	BaseType_t gotSomething = xQueueReceive( 	xQueue,				/* The queue being read. */
													&RecInt,	/* Data is read into this address. */
													( TickType_t ) 0 );	/* Wait without a timeout for data. */
    	if(gotSomething == pdTRUE && RecInt == 1){
    		Neopixel.NeopixelStop();
    		sleep_A9(1);
    		vTaskDelete( xLedMatrixTask );
    	}
	}
}

/*-----------------------------------------------------------*/

//static void prvRxTask( void *pvParameters )
//{
//char Recdstring[15] = "";

//	for( ;; )
//	{
		/* Block to wait for data arriving on the queue. */
//		xQueueReceive( 	xQueue,				/* The queue being read. */
//						Recdstring,	/* Data is read into this address. */
//						portMAX_DELAY );	/* Wait without a timeout for data. */

		/* Print the received data. */
//		xil_printf( "Rx task received string from Tx task: %s\r\n", Recdstring );
//		RxtaskCntr++;
//	}
//}


/*-----------------------------------------------------------*/
static void vTimerCallback( TimerHandle_t pxTimer )
{
	long lTimerId;
	configASSERT( pxTimer );

	lTimerId = ( long ) pvTimerGetTimerID( pxTimer );

	if (lTimerId != TIMER_ID) {
		xil_printf("FreeRTOS Hello World Example FAILED");
	}

	/* If the RxtaskCntr is updated every time the Rx task is called. The
	 Rx task is called every time the Tx task sends a message. The Tx task
	 sends a message every 1 second.
	 The timer expires after 10 seconds. We expect the RxtaskCntr to at least
	 have a value of 9 (TIMER_CHECK_THRESHOLD) when the timer expires. */
//	if (RxtaskCntr >= TIMER_CHECK_THRESHOLD) {
//		xil_printf("Successfully ran FreeRTOS Hello World Example");
//	} else {
//		xil_printf("FreeRTOS Hello World Example FAILED");
//	}

//	vTaskDelete( xRxTask );
//	vTaskDelete( xLedMatrixTask );
//	uint8_t tmp = 1;
//	xQueueSend( xQueue,			/* The queue being written to. */
//				&tmp, /* The address of the data being sent. */
//				0UL );			/* The block time. */
}

